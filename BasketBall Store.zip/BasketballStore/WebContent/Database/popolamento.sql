use basket;

INSERT INTO admin 	 (NomeUtente,Pass)
					 VALUES ('admin','admin');

INSERT INTO prodotti (Id,Immagine,Descrizione,Prezzo,Taglia,Disponibilità)
					 VALUES ('1','img\\izzo.png','Luca Izzo Scafati Jersey','99','L','20');
INSERT INTO prodotti (Id,Immagine,Descrizione,Prezzo,Taglia,Disponibilità)
					 VALUES ('2','http://nba.frgimages.com/FFImage/thumb.aspx?i=/productImages/_1852000/ff_1852489_full.jpg&w=340','Lebron James Cavs jersey','40','L','20');
INSERT INTO prodotti (Id,Immagine,Descrizione,Prezzo,Taglia,Disponibilità)
					 VALUES ('8','http://nba.frgimages.com/FFImage/thumb.aspx?i=/productImages/_491000/ff_491925_xl.jpg&w=340','Steph Curry GSW Jersey','49','S','15');
INSERT INTO prodotti (Id,Immagine,Descrizione,Prezzo,Taglia,Disponibilità)
					 VALUES ('3','http://nba.frgimages.com/FFImage/thumb.aspx?i=/productImages/_1191000/ff_1191816_xl.jpg&w=340','Micheal Jordan Bulls Jersey','35','XL','10');
INSERT INTO prodotti (Id,Immagine,Descrizione,Prezzo,Taglia,Disponibilità)
					 VALUES ('4','http://nba.frgimages.com/FFImage/thumb.aspx?i=/productImages/_1308000/ff_1308548_full.jpg&w=340','Shaq Orlando Magic Jersey','42','XXL','9');
INSERT INTO prodotti (Id,Immagine,Descrizione,Prezzo,Taglia,Disponibilità)
					 VALUES ('6','https://cdn.shopify.com/s/files/1/0289/9673/products/TUNE_SQUAD_BUGS_1_3_grande.jpg?v=1450142783','Bugs Bunny Space Jam Jersey','47','XS','12');
INSERT INTO prodotti (Id,Immagine,Descrizione,Prezzo,Taglia,Disponibilità)
					 VALUES ('7','https://cdn.shopify.com/s/files/1/0289/9673/products/TUNE_SQUAD_LOLA_10_3_grande.jpg?v=1450142803','Lola Bunny Space Jam Jersey','32','L','20');
INSERT INTO prodotti (Id,Immagine,Descrizione,Prezzo,Taglia,Disponibilità)
					 VALUES ('9','http://i.ebayimg.com/00/s/NDk5WDUwMA==/z/wW8AAOxyVaBS-sVQ/$_35.JPG?set_id=2','Steve Nash Jersey','48','L','30');


INSERT INTO cliente  (NomeUtenteCliente, PassCliente, Nome, Cognome, Email)
					 VALUES ('advancesluca','luca','Luca','Izzo','izzo.lu@hotmail.it');
INSERT INTO cliente  (NomeUtenteCliente, PassCliente, Nome, Cognome, Email)
					 VALUES ('zaccazuzzu','zuzzu','Zaccaria','Zuzzu','z.zuzzu71@conpecore.corn');